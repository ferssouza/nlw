'''
const mensagem = "Bom te ver aqui! "
alert(mensagem + (10 * 100) + "abraços")
'''